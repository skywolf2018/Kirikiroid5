package org.tvp.kirikiri2;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.vending.licensing.AESObfuscator;
import com.google.android.vending.licensing.DeviceLimiter;
import com.google.android.vending.licensing.LicenseChecker;
import com.google.android.vending.licensing.LicenseCheckerCallback;
import com.google.android.vending.licensing.LicenseValidator;
import com.google.android.vending.licensing.NullDeviceLimiter;
import com.google.android.vending.licensing.Policy;
import com.google.android.vending.licensing.ServerManagedPolicy;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference; // 新增导入：用于修复内存泄漏
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.PublicKey;
import java.util.ArrayList; // 补全导入
import java.util.Date;
import java.util.List; // 补全导入

/* JADX INFO: loaded from: classes.dex */
public class Kirikiroid2 extends KR2Activity {
    private static final String TAG = "Kirikiroid2";
    private static final String BASE64_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiQYVk7Nt+zFiElM05HOC7EAf1hyvM82dS+AlTWJbxUhIeUMXjs3g7gRPZGKKxlhIGlqFc2C4cdzlY/hnb82pxkTobpEDMaT25ys0DdzU3t+bAMKS1c3JIjknNrbPq946qL2pSGedlCQZUHsNuzea3yupwVgj/bBAyOrWALLuxuqYhRr1gf8wbTwRQffY200p7auW+K1xD0olyeA5r650/4DVPGBZ6L9YKhpHzsBu4X8aXyGzLR2D1ThRG79Ro9tTLe7S/ZUX3gzMwL87FfDzxgtTzi2wFvMBWdSK/94qPZyujH/HZBWVXqzC3SgFC+nEWI6xp1KW0PAK0A/WQsuDzwIDAQAB";
    static Kirikiroid2 KR2Instance;
    private LicenseChecker mChecker = null;
    private LicenseCheckerCallback mLicenseCheckerCallback;
    static String sSignedData = null;
    static String sSignature = null;
    static int lastResponseCode = -1;
    static String s_postdata = null;
    static ProgressDialog progDiag = null;
    private static final byte[] SALT = { -46, 65, 30, -128, -103, -57, 74, -64, 51, 88, -95, -45, 77, -117, -36, -113, -11, 32, -64, 89 };

    // --- 修复开始：使用静态内部类和弱引用 ---
    private static class SafeHandler extends Handler {
        private final WeakReference<Kirikiroid2> activityReference;

        SafeHandler(Kirikiroid2 activity) {
            super(Looper.getMainLooper());
            this.activityReference = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            Kirikiroid2 activity = activityReference.get();
            // 如果 Activity 已被销毁，直接返回，不再处理消息
            if (activity == null || activity.isFinishing()) {
                return;
            }
            if (activity.progDiag != null && activity.progDiag.isShowing()) {
                activity.progDiag.dismiss();
            }
            if (msg.what != 0) {
                activity.MessageBoxOnLicenseFail(activity.getString(msg.what));
                return;
            }
            Bundle bundle = msg.getData();
            if (bundle == null) {
                return;
            }
            String err = bundle.getString("err");
            if (err != null) {
                activity.MessageBoxOnLicenseFail(err);
                return;
            }
            try {
                byte[] data = bundle.getByteArray("data");
                if (data == null) {
                    return;
                }
                FileOutputStream fos = new FileOutputStream(
                        new File(activity.getFilesDir(), "license.sig")
                );
                fos.write(data);
                fos.close();
            } catch (Exception e) {
                Log.e(TAG, "license save error", e);
            }
        }
    }

    // 实例化新的 Handler
    private final SafeHandler handler = new SafeHandler(this);
    // --- 修复结束 ---

    /*
     * Android 文件打开入口
     */
    private void handleOpenIntent() {
        Intent intent = getIntent();
        if (intent == null) {
            return;
        }
        Uri uri = intent.getData();
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && uri != null) {
            String path = uri.getPath();
            if (path != null) {
                Log.i(TAG, "Open game path:" + path);
                getSharedPreferences("KR2", MODE_PRIVATE)
                        .edit()
                        .putString("GAME_PATH", path)
                        .apply();
            }
        }
    }

    private class MyLicenseValidator extends LicenseValidator {
        MyLicenseValidator(Policy policy, DeviceLimiter deviceLimiter, LicenseCheckerCallback callback, int nonce, String packageName, String versionCode) {
            super(policy, deviceLimiter, callback, nonce, packageName, versionCode);
        }

        @Override
        public void verify(PublicKey publicKey, int responseCode, String signedData, String signature) {
            lastResponseCode = responseCode;
            sSignedData = signedData;
            sSignature = signature;
            super.verify(publicKey, responseCode, signedData, signature);
        }
    }

    private class MyLicenseCheckerCallback implements LicenseCheckerCallback {
        @Override
        public void allow(int policyReason) {
            if (!isFinishing()) {
                downloadLicense();
            }
        }

        @Override
        public void dontAllow(int policyReason) {
            if (isFinishing()) {
                return;
            }
            MessageBoxOnLicenseFail("License check failed : " + lastResponseCode);
        }

        @Override
        public void applicationError(int errorCode) {
            MessageBoxOnLicenseFail("License error : " + errorCode);
        }
    }

    void MessageBoxOnLicenseFail(String reason) {
        new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_launcher)
                .setTitle(R.string.license_fail)
                .setMessage(reason)
                .setPositiveButton(R.string.retry, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        updateLicense();
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .show();
    }

    public void downloadLicense() {
        try {
            s_postdata = "?platform=Android"
                    + "&uid=" + URLEncoder.encode(getKR2DeviceId(), "UTF-8")
                    + "&data=" + URLEncoder.encode(sSignedData, "UTF-8")
                    + "&sign=" + URLEncoder.encode(sSignature, "UTF-8")
                    + "&timestamp=" + (new Date().getTime());
            progDiag = ProgressDialog.show(this, "please wait", "downloading", true, false);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Message msg = new Message();
                    msg.what = 0;
                    try {
                        URLConnection con = new URL("https://raw.githubusercontent.com/zeas2/Kirikiroid2_patch/master/js/active.url")
                                .openConnection();
                        BufferedInputStream input = new BufferedInputStream(con.getInputStream());
                        byte[] buffer = new byte[4096];
                        int length = input.read(buffer);
                        input.close();
                        if (length <= 0) {
                            msg.what = R.string.license_data_damaged;
                            handler.sendMessage(msg);
                            return;
                        }
                        String url = new String(buffer, 0, length, "UTF-8");
                        URLConnection con2 = new URL(url + s_postdata).openConnection();
                        BufferedInputStream input2 = new BufferedInputStream(con2.getInputStream());
                        int size = input2.read(buffer);
                        input2.close();
                        if (size <= 0) {
                            msg.what = R.string.license_data_damaged;
                            handler.sendMessage(msg);
                            return;
                        }
                        String result = new String(buffer, 0, size, "UTF-8");
                        Bundle data = new Bundle();
                        if (!result.startsWith("-- SIGNATURE - SHA256/PSS/RSA --")) {
                            data.putString("err", result);
                        } else {
                            data.putByteArray("data", buffer);
                        }
                        msg.setData(data);
                    } catch (Exception e) {
                        msg.what = R.string.recheck_network;
                        Bundle b = new Bundle();
                        b.putString("err", e.getMessage());
                        msg.setData(b);
                    }
                    handler.sendMessage(msg);
                }
            }).start();
        } catch (Exception e) {
            MessageBoxOnLicenseFail(e.getMessage());
        }
    }

    // 补全 onCreate 方法（根据上传文档末尾推断）
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        KR2Instance = this;
        handleOpenIntent();
        // 补全文档末尾缺失的逻辑
        ArrayList<File> games = GameScanner.scan(Environment.getExternalStorageDirectory());
        GameScanner.saveCache(this, games);
    }
}